# SignalTrace V2 Notes

Implementation uses strict ingestion and deduplication, offline extraction validation against
the original complaint, and deterministic Python evidence rules. Live mode supports Gemini
or Groq through environment variables; customer text and shipment details are never trusted
as instructions.

Tests performed: the smoke output was compared with `data/smoke/expected.json`; the challenge
offline run was generated with the supplied extractions; Python compilation and six focused
unit/regression tests were run.

Known limitation: live results depend on provider availability, quota, and model output. Any
failed live extraction is counted in `llm_errors` and produces an `OTHER`/`NOT_APPLICABLE` case
rather than allowing the model to decide a verdict.

Security risk: an API key in the process environment or provider request could be exposed by
an unsafe host environment; keys are not stored or written to output.

Live provider/result: on 2026-10-26 Groq initially returned HTTP 403/code 1010 when Python's
default HTTP client signature was used. Sending an explicit application `User-Agent` resolved
the provider block. The full sample run with `openai/gpt-oss-20b` then completed with 15 cases
and zero `llm_errors`. No Gemini credential was configured. The application supports Gemini
when `GEMINI_API_KEY` is supplied. Provider availability, quota, and model access vary by account.
