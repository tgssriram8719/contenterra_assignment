import csv
import json
import re
from datetime import datetime

# strict UTC format: 2026-10-25T09:00:00Z
TS_REGEX = re.compile(
    r"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$"
)
VALID_STATUSES = {"SUCCESS", "FAILED", "PENDING"}


def parse_ts(val):
    """returns datetime if val is a valid UTC timestamp, else None"""
    if not TS_REGEX.match(val):
        return None
    try:
        return datetime.strptime(val, "%Y-%m-%dT%H:%M:%SZ")
    except ValueError:
        # catches impossible dates like Feb 30
        return None


def load_payments(path):
    rows = []
    seen = set()
    stats = {"total": 0, "accepted": 0, "invalid": 0, "duplicates": 0}

    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # fully blank row doesn't count
            if all(not isinstance(v, str) or not v.strip() for v in row.values()):
                continue

            stats["total"] += 1

            def text(field):
                value = row.get(field)
                return value.strip() if isinstance(value, str) else ""

            pid = text("payment_id")
            oid = text("order_id")
            ts_raw = text("timestamp")
            status = text("status")
            amt_raw = text("amount_cents")
            pref = text("provider_ref")

            # --- validation ---
            if not pid or not oid or not ts_raw or not status or not amt_raw:
                stats["invalid"] += 1
                continue

            ts = parse_ts(ts_raw)
            if ts is None:
                stats["invalid"] += 1
                continue

            if status not in VALID_STATUSES:
                stats["invalid"] += 1
                continue

            try:
                amount = int(amt_raw)
            except ValueError:
                stats["invalid"] += 1
                continue
            if amount <= 0:
                stats["invalid"] += 1
                continue

            # SUCCESS needs a provider_ref
            if status == "SUCCESS" and not pref:
                stats["invalid"] += 1
                continue

            # dedup — invalid rows DON'T reserve the id
            if pid in seen:
                stats["duplicates"] += 1
                continue

            seen.add(pid)
            stats["accepted"] += 1
            rows.append({
                "payment_id": pid,
                "order_id": oid,
                "timestamp": ts_raw,
                "ts": ts,
                "status": status,
                "amount_cents": amount,
                "provider_ref": pref,
            })

    # sort by timestamp then id for rule application
    rows.sort(key=lambda r: (r["ts"], r["payment_id"]))
    return rows, stats


def load_shipments(path):
    rows = []
    seen = set()
    stats = {"total": 0, "accepted": 0, "invalid": 0, "duplicates": 0}

    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            stats["total"] += 1

            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                stats["invalid"] += 1
                continue

            if not isinstance(obj, dict):
                stats["invalid"] += 1
                continue

            eid = obj.get("event_id")
            oid = obj.get("order_id")
            ts_raw = obj.get("timestamp")
            etype = obj.get("event_type")

            # need nonempty strings for all required fields
            for val in [eid, oid, ts_raw, etype]:
                if not isinstance(val, str) or not val.strip():
                    break
            else:
                # all passed
                eid = eid.strip()
                oid = oid.strip()
                ts_raw = ts_raw.strip()
                etype = etype.strip()

                ts = parse_ts(ts_raw)
                if ts is None:
                    stats["invalid"] += 1
                    continue

                if eid in seen:
                    stats["duplicates"] += 1
                    continue

                seen.add(eid)
                stats["accepted"] += 1
                rows.append({
                    "event_id": eid,
                    "order_id": oid,
                    "timestamp": ts_raw,
                    "ts": ts,
                    "event_type": etype,
                    "details": obj.get("details", "") if isinstance(obj.get("details"), str) else "",
                })
                continue

            # if the for-else didn't hit 'else', one of the checks failed
            stats["invalid"] += 1

    rows.sort(key=lambda r: (r["ts"], r["event_id"]))
    return rows, stats


def load_complaints(path):
    rows = []
    seen = set()
    stats = {"total": 0, "accepted": 0, "invalid": 0, "duplicates": 0}

    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            stats["total"] += 1

            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                stats["invalid"] += 1
                continue

            if not isinstance(obj, dict):
                stats["invalid"] += 1
                continue

            tid = obj.get("ticket_id")
            msg = obj.get("message")

            if not isinstance(tid, str) or not tid.strip():
                stats["invalid"] += 1
                continue
            if not isinstance(msg, str) or not msg.strip():
                stats["invalid"] += 1
                continue

            tid = tid.strip()
            msg = msg.strip()

            if tid in seen:
                stats["duplicates"] += 1
                continue

            seen.add(tid)
            stats["accepted"] += 1
            rows.append({"ticket_id": tid, "message": msg})

    return rows, stats
