from datetime import timedelta


def check_double_charge(order_id, payments):
    """
    Two SUCCESS payments, same amount, different provider_ref.
    Pick the earliest qualifying 'second' payment, then the earliest
    matching 'first' before it.
    """
    successes = [
        p for p in payments
        if p["order_id"] == order_id and p["status"] == "SUCCESS"
    ]

    if len(successes) < 2:
        return []

    # payments are already sorted by (ts, payment_id)
    for i in range(1, len(successes)):
        for j in range(i):
            if (successes[j]["amount_cents"] == successes[i]["amount_cents"]
                    and successes[j]["provider_ref"] != successes[i]["provider_ref"]):
                return [successes[j]["payment_id"], successes[i]["payment_id"]]

    return []


def check_payment_failures(order_id, payments):
    """
    3 consecutive FAILED payments within a 10-minute window (first to third).
    PENDING/SUCCESS don't break the sequence — we only look at FAILED rows.
    """
    failed = [
        p for p in payments
        if p["order_id"] == order_id and p["status"] == "FAILED"
    ]

    if len(failed) < 3:
        return []

    for i in range(len(failed) - 2):
        span = failed[i + 2]["ts"] - failed[i]["ts"]
        if span <= timedelta(minutes=10):
            return [failed[i]["payment_id"],
                    failed[i + 1]["payment_id"],
                    failed[i + 2]["payment_id"]]

    return []


def check_shipped_unpaid(order_id, payments, shipments):
    """
    Earliest SHIPMENT_CREATED with no SUCCESS payment *strictly before* it.
    Same-timestamp payment does NOT count as 'earlier'.
    """
    created = [
        s for s in shipments
        if s["order_id"] == order_id and s["event_type"] == "SHIPMENT_CREATED"
    ]

    if not created:
        return []

    success_times = [
        p["ts"] for p in payments
        if p["order_id"] == order_id and p["status"] == "SUCCESS"
    ]

    for ship in created:  # already sorted
        if not any(st < ship["ts"] for st in success_times):
            return [ship["event_id"]]

    return []

