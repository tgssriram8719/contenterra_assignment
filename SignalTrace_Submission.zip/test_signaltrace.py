import json
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import main as app
from ingest import load_payments
from rules import check_double_charge, check_payment_failures, check_shipped_unpaid


ROOT = Path(__file__).resolve().parent


def payment(payment_id, timestamp, status, amount=1000, provider_ref=""):
    return {
        "payment_id": payment_id,
        "order_id": "ORD-101",
        "timestamp": timestamp,
        "ts": datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%SZ"),
        "status": status,
        "amount_cents": amount,
        "provider_ref": provider_ref,
    }


class SignalTraceTests(unittest.TestCase):
    def test_json_request_sends_application_user_agent(self):
        response = mock.MagicMock()
        response.__enter__.return_value = response
        response.read.return_value = b'{"ok": true}'
        response.__exit__.return_value = False

        with mock.patch.object(
            app.urllib.request, "urlopen", return_value=response
        ) as urlopen:
            self.assertEqual(
                app._json_request("https://example.invalid", {"test": True}),
                {"ok": True},
            )

        request = urlopen.call_args.args[0]
        self.assertEqual(request.get_header("User-agent"), "SignalTrace/2.0")

    def test_smoke_result_matches_supplied_expected_output(self):
        args = SimpleNamespace(
            payments=ROOT / "data/smoke/payments.csv",
            shipments=ROOT / "data/smoke/shipments.jsonl",
            complaints=ROOT / "data/smoke/complaints.jsonl",
            extractions=ROOT / "data/smoke/extractions.json",
        )
        with open(ROOT / "data/smoke/expected.json", encoding="utf-8") as file:
            expected = json.load(file)
        self.assertEqual(app.build_result(args), expected)

    def test_extraction_requires_one_ascii_order_id_and_matching_suggestion(self):
        extraction = {"order_id": "ORD-123", "issue": "DOUBLE_CHARGE"}
        complaint = {"message": "ORD-123 appears twice: ORD-123", "ticket_id": "T1"}
        self.assertEqual(
            app.validate_extraction(complaint, extraction),
            ("ORD-123", "DOUBLE_CHARGE"),
        )

        complaint["message"] = "Compare ORD-123 with ORD-124"
        self.assertEqual(app.validate_extraction(complaint, extraction)[0], None)

        complaint["message"] = "Unicode digits are not an ID: ORD-१२३"
        self.assertEqual(app.validate_extraction(complaint, extraction)[0], None)

        complaint["message"] = "The order is ORD-123"
        extraction["order_id"] = "ORD-999"
        extraction["issue"] = "UNKNOWN"
        self.assertEqual(app.validate_extraction(complaint, extraction), (None, "OTHER"))

    def test_invalid_payment_does_not_reserve_id_and_later_duplicate_does(self):
        rows = (
            "payment_id,order_id,timestamp,status,amount_cents,provider_ref\n"
            "P1,ORD-101,bad,SUCCESS,1000,GW-A\n"
            "P1,ORD-101,2026-10-25T10:00:00Z,SUCCESS,1000,GW-A\n"
            "P1,ORD-101,2026-10-25T10:01:00Z,SUCCESS,1000,GW-B\n"
        )
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "payments.csv"
            path.write_text(rows, encoding="utf-8")
            accepted, stats = load_payments(path)
        self.assertEqual(stats, {"total": 3, "accepted": 1, "invalid": 1, "duplicates": 1})
        self.assertEqual(accepted[0]["provider_ref"], "GW-A")

    def test_detection_boundaries_and_deterministic_evidence(self):
        payments = [
            payment("P1", "2026-10-25T10:00:00Z", "SUCCESS", 1000, "GW-A"),
            payment("P2", "2026-10-25T10:01:00Z", "SUCCESS", 2000, "GW-B"),
            payment("P3", "2026-10-25T10:02:00Z", "SUCCESS", 1000, "GW-C"),
        ]
        self.assertEqual(check_double_charge("ORD-101", payments), ["P1", "P3"])

        failures = [
            payment("F1", "2026-10-25T11:00:00Z", "FAILED"),
            payment("F2", "2026-10-25T11:05:00Z", "FAILED"),
            payment("F3", "2026-10-25T11:10:00Z", "FAILED"),
        ]
        self.assertEqual(check_payment_failures("ORD-101", failures), ["F1", "F2", "F3"])
        failures[-1] = payment("F3", "2026-10-25T11:10:01Z", "FAILED")
        self.assertEqual(check_payment_failures("ORD-101", failures), [])

        shipment = {
            "event_id": "S1",
            "order_id": "ORD-101",
            "event_type": "SHIPMENT_CREATED",
            "ts": datetime(2026, 10, 25, 10, 0, 0),
        }
        same_time_success = [
            payment("P4", "2026-10-25T10:00:00Z", "SUCCESS", 1000, "GW-D")
        ]
        self.assertEqual(
            check_shipped_unpaid("ORD-101", same_time_success, [shipment]),
            ["S1"],
        )

    def test_non_object_live_response_is_counted_as_llm_error(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "payments.csv").write_text(
                "payment_id,order_id,timestamp,status,amount_cents,provider_ref\n"
                "P1,ORD-101,2026-10-25T10:00:00Z,SUCCESS,1000,GW-A\n",
                encoding="utf-8",
            )
            (root / "shipments.jsonl").write_text("", encoding="utf-8")
            (root / "complaints.jsonl").write_text(
                '{"ticket_id":"T1","message":"Complaint for ORD-101"}\n',
                encoding="utf-8",
            )
            args = SimpleNamespace(
                payments=root / "payments.csv",
                shipments=root / "shipments.jsonl",
                complaints=root / "complaints.jsonl",
                extractions=None,
            )
            with mock.patch.object(app, "request_live_extraction", return_value=[]):
                result = app.build_result(args)

        self.assertEqual(result["stats"]["llm_errors"], 1)
        self.assertEqual(
            result["cases"][0],
            {
                "ticket_id": "T1",
                "order_id": None,
                "issue": "OTHER",
                "verdict": "NOT_APPLICABLE",
                "evidence_ids": [],
            },
        )


if __name__ == "__main__":
    unittest.main()
